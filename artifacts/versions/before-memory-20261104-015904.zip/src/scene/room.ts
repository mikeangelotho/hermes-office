import * as THREE from 'three';
import { PALETTE as P } from './palette.ts';
import { hologramMaterial, type SurfaceRole } from './hologram.ts';
import type { GlassUniforms } from './spatial-glass.ts';

/** Shared primitives and instanced static geometry keep the room cheap to draw. */
export class Assets {
  geometries = new Map<string, THREE.BufferGeometry>();
  materials = new Map<string, THREE.MeshLambertMaterial>();
  textures = new Set<THREE.Texture>();
  private hologramTime = { value: 0 };
  readonly glass: GlassUniforms = { texture: { value: null }, viewport: { value: new THREE.Vector2(1,1) }, ready: { value: 0 } };
  tickHolograms(time: number, reduced: boolean) { if (!reduced) this.hologramTime.value = time; }
  geometry(kind = 'box') {
    if (!this.geometries.has(kind)) this.geometries.set(kind, kind === 'cylinder' ? new THREE.CylinderGeometry(.5, .5, 1, 8) : kind === 'cone' ? new THREE.ConeGeometry(.5, 1, 6) : kind === 'leaf' ? new THREE.IcosahedronGeometry(.5, 0) : kind === 'sphere' ? new THREE.SphereGeometry(.5, 8, 6) : new THREE.BoxGeometry(1, 1, 1));
    return this.geometries.get(kind)!;
  }
  material(color: string, kind = 'box', role: SurfaceRole = 'environment') {
    const key = `${role}:${color}:${kind}`;
    if (!this.materials.has(key)) this.materials.set(key, hologramMaterial(color, kind, this.hologramTime, role, this.glass));
    return this.materials.get(key)!;
  }
  mesh(color: string, size: number[], position: number[], kind = 'box', parent?: THREE.Object3D, role: SurfaceRole = 'environment') {
    const mesh = new THREE.Mesh(this.geometry(kind), this.material(color, kind, role));
    mesh.scale.set(size[0], size[1], size[2]); mesh.position.set(position[0], position[1], position[2]);
    mesh.castShadow = true; mesh.receiveShadow = true; parent?.add(mesh); return mesh;
  }
  texture(width: number, height: number, paint: (ctx: CanvasRenderingContext2D) => void) {
    const canvas = document.createElement('canvas'); canvas.width = width; canvas.height = height;
    paint(canvas.getContext('2d')!); const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace; texture.magFilter = THREE.NearestFilter; texture.minFilter = THREE.LinearFilter;
    this.textures.add(texture); return texture;
  }
  dispose() { this.geometries.forEach(g => g.dispose()); this.materials.forEach(m => m.dispose()); this.textures.forEach(t => t.dispose()); }
}
interface StaticPart { color: string; kind: string; matrix: THREE.Matrix4; }
export interface RoomModel { group: THREE.Group; screens: THREE.Mesh[]; screenOn: THREE.MeshLambertMaterial; screenOff: THREE.MeshLambertMaterial; dispose: () => void; }

export function createRoom(a: Assets): RoomModel {
  const group = new THREE.Group(); const parts: StaticPart[] = [];
  const transform = new THREE.Object3D();
  const part = (color: string, size: number[], at: number[], kind = 'box', rotation = 0) => {
    transform.position.set(at[0], at[1], at[2]); transform.scale.set(size[0], size[1], size[2]); transform.rotation.set(0, rotation, 0); transform.updateMatrix();
    parts.push({ color, kind, matrix: transform.matrix.clone() });
  };
  const leg = (x: number, z: number, h: number, color: string = P.metal) => part(color, [.075, h, .075], [x, h / 2, z]);
  // A floating architectural model, not an infinite game level.
  part(P.foundation, [15.2, .25, 12.2], [0, -.29, 0]);
  part(P.floor, [15.05, .22, 12.05], [0, -.08, 0]);
  for (let x = 0; x < 15; x++) for (let z = 0; z < 12; z++) part((x + z) % 2 ? P.floorAlt : P.floor, [.99, .025, .99], [-7 + x, .045, -5.5 + z]);
  part(P.wall, [15.1, 3.65, .2], [0, 1.85, -5.9]);
  part(P.wall, [.2, 3.65, 12], [-7.45, 1.85, 0]);
  part(P.frame, [15.2, .13, .29], [0, 3.74, -5.9]);
  part(P.frame, [.29, .13, 12.15], [-7.45, 3.74, 0]);
  part(P.frame, [15, .14, .12], [0, .18, -5.74]);
  part(P.frame, [.12, .14, 11.7], [-7.29, .18, 0]);
  // Three daylight windows; geometry supplies pixel-like mullions.
  for (const x of [-1.55, 1.65, 4.85]) {
    part(P.frame, [2.67, 1.99, .09], [x, 2.39, -5.74]);
    part(P.glass, [2.46, 1.79, .1], [x, 2.4, -5.67]);
    part(P.glass, [2.35, .56, .025], [x, 2.97, -5.6]);
    for (const dx of [-1.24, 0, 1.24]) part(P.frame, [.07, 1.91, .12], [x + dx, 2.4, -5.57]);
    part(P.frame, [2.6, .07, .12], [x, 2.5, -5.57]);
    part(P.frame, [2.85, .13, .37], [x, 1.45, -5.48]);
  }
  // Framed typographic print on the back wall.
  const printTexture = a.texture(256, 320, ctx => {
    ctx.fillStyle = P.screen; ctx.fillRect(0, 0, 256, 320);
    ctx.fillStyle = P.ice; ctx.beginPath(); ctx.arc(128, 101, 65, Math.PI, 0); ctx.fill();
    ctx.fillRect(63, 100, 130, 54); ctx.fillStyle = P.blue; ctx.fillRect(96, 100, 64, 54);
    ctx.font = 'bold 32px monospace'; ctx.textAlign = 'center'; ctx.fillText('HERMES.', 128, 219);
    ctx.font = '20px monospace'; ctx.fillText('OFFICE HOURS.', 128, 252);
  });
  const printMat = a.material(P.muted, 'plane'); printMat.map = printTexture;
  part(P.frame, [1.82, 2.25, .12], [-5.5, 2.35, -5.66]);
  const print = new THREE.Mesh(new THREE.PlaneGeometry(1.65, 2.08), printMat); print.position.set(-5.5, 2.35, -5.58); group.add(print);
  // Whiteboard with colorful, deliberately non-private notes.
  part(P.frame, [.1, 1.6, 2.8], [-7.28, 2.2, -1.5]);
  part(P.muted, [.12, 1.45, 2.65], [-7.2, 2.2, -1.5]);
  for (let i = 0; i < 6; i++) part([P.blue, P.azure, P.blue][i % 3], [.025, .31, .34], [-7.12, 2.5 - Math.floor(i / 3) * .5, -2.3 + (i % 3) * .65]);
  // Workstations: ten seats, shared by whichever team occupies this room.
  const screenTexture = a.texture(128, 80, ctx => {
    ctx.fillStyle = P.screen; ctx.fillRect(0, 0, 128, 80);
    ctx.fillStyle = P.muted; ctx.fillRect(0, 0, 128, 10);
    for (let i = 0; i < 7; i++) { ctx.fillStyle = i % 3 === 0 ? P.azure : P.azure; ctx.fillRect(10 + i % 2 * 7, 19 + i * 7, 25 + (i * 11) % 58, 2); }
    ctx.fillStyle = P.blue; ctx.fillRect(94, 57, 23, 13);
  });
  const screenOn = a.material(P.azure, 'plane', 'screen');
  screenOn.map = screenTexture; screenOn.emissiveMap = screenTexture;
  const screenOff = a.material(P.metal, 'plane');
  const screens: THREE.Mesh[] = [];
  for (let i = 0; i < 10; i++) {
    const x = -5.1 + i % 5 * 2.55; const z = i < 5 ? -3.2 : -.3;
    part(P.glass, [1.9, .13, 1.12], [x, 1.03, z]);
    part(P.glass, [1.95, .045, 1.16], [x, 1.11, z]);
    for (const dx of [-.79, .79]) for (const dz of [-.43, .43]) leg(x + dx, z + dz, .99);
    part(P.metal, [.6, .045, .31], [x, 1.16, z - .17]);
    part(P.metal, [.07, .31, .08], [x, 1.32, z - .26]);
    part(P.metal, [1.1, .72, .105], [x, 1.72, z - .3]);
    const screen = new THREE.Mesh(new THREE.PlaneGeometry(.96, .58), screenOff); screen.position.set(x, 1.73, z - .238); group.add(screen); screens.push(screen);
    part(P.ice, [.67, .035, .23], [x, 1.16, z + .3]);
    for (let k = 0; k < 5; k++) part(P.metal, [.055, .008, .11], [x - .25 + k * .12, 1.18, z + .3]);
    part(P.muted, [.13, .055, .18], [x + .55, 1.18, z + .28], 'sphere');
    // Chairs face toward the screens. Their backs remain visible in a cutaway view.
    part(P.metal, [.63, .11, .6], [x, .55, z + 1.05]);
    part(P.metal, [.64, .62, .1], [x, .91, z + 1.33]);
    leg(x, z + 1.05, .5, P.metal);
    part(P.metal, [.65, .06, .11], [x, .09, z + 1.05]);
    part(P.metal, [.11, .06, .57], [x, .09, z + 1.05]);
    if (i % 3 === 0) { part(P.muted, [.15, .21, .15], [x - .68, 1.25, z + .28], 'cylinder'); part(P.muted, [.11, .015, .11], [x - .68, 1.36, z + .28], 'cylinder'); }
  }
  // A knitted geometric rug and two long modular sofas.
  part(P.muted, [12.7, .035, 3.12], [0, .09, 3.36]);
  for (const x of [-5.6, -3.6, -1.6, 1.6, 3.6, 5.6]) part(P.muted, [.65, .012, 2.7], [x, .115, 3.36]);
  for (const side of [-1, 1]) {
    const x = side * 3.7; const sofaColor = side === -1 ? P.furniture : P.furniture; const cushion = side === -1 ? P.cushion : P.cushion;
    part(P.furniture, [5.1, .18, 1.05], [x, .25, 3.56]);
    part(sofaColor, [5.35, .66, .3], [x, .75, 3.12]);
    for (const dx of [-2.6, 2.6]) part(sofaColor, [.3, .58, 1.1], [x + dx, .63, 3.58]);
    for (let i = 0; i < 5; i++) part(cushion, [.96, .25, .88], [x - 2 + i, .49, 3.66]);
    part(side === -1 ? P.azure : P.azure, [.46, .48, .22], [x - 1.5, .86, 3.42], 'box', .18);
  }
  // A little table between the sofas with a book and a tiny plant.
  part(P.furniture, [1.25, .12, 1.25], [0, .56, 3.58], 'cylinder');
  for (const [x, z] of [[-.35, 3.3], [.35, 3.3], [0, 3.95]]) leg(x, z, .5, P.furniture);
  part(P.muted, [.45, .07, .52], [-.17, .66, 3.5], 'box', -.22);
  part(P.ice, [.38, .04, .45], [-.17, .71, 3.5], 'box', -.22);
  const plant = (x: number, z: number, size = 1) => {
    part(P.furniture, [.52 * size, .54 * size, .52 * size], [x, .3 * size, z], 'cylinder');
    part(P.furniture, [.6 * size, .12 * size, .6 * size], [x, .57 * size, z], 'cylinder');
    for (let i = 0; i < 5; i++) {
      const theta = i * 2.4; const r = .27 * size;
      part(P.leaf, [.06 * size, .85 * size, .06 * size], [x + Math.sin(theta) * r / 2, .95 * size, z + Math.cos(theta) * r / 2], 'cylinder');
      part(i % 2 ? P.leafLight : P.leaf, [.62 * size, .65 * size, .44 * size], [x + Math.sin(theta) * r, 1.35 * size + i % 2 * .2, z + Math.cos(theta) * r], 'leaf', theta);
    }
  };
  plant(-6.6, -4.7, .85); plant(6.7, -4.9, .9); plant(-6.75, 1.5, .8);
  // A low book cabinet and record player.
  part(P.furniture, [2.8, 1, .65], [-4.1, .6, -5.13]);
  part(P.furniture, [2.9, .1, .72], [-4.1, 1.15, -5.13]);
  for (let i = 0; i < 10; i++) part([P.furniture, P.blue, P.blue, P.furniture][i % 4], [.12, .49 + i % 3 * .06, .37], [-5.2 + i * .19, .65, -4.91]);
  part(P.metal, [.62, .12, .5], [-3.5, 1.28, -5.07]);
  part(P.metal, [.35, .025, .35], [-3.5, 1.36, -5.07], 'cylinder');
  // Batch all static parts by shared geometry/material.
  const batches = new Map<string, StaticPart[]>();
  for (const item of parts) { const key = `${item.kind}:${item.color}`; const batch = batches.get(key) ?? []; batch.push(item); batches.set(key, batch); }
  for (const items of batches.values()) {
    const mesh = new THREE.InstancedMesh(a.geometry(items[0].kind), a.material(items[0].color, items[0].kind), items.length);
    items.forEach((item, i) => mesh.setMatrixAt(i, item.matrix)); mesh.castShadow = true; mesh.receiveShadow = true; mesh.computeBoundingSphere(); group.add(mesh);
  }
  return { group, screens, screenOn, screenOff, dispose: () => { print.geometry.dispose(); screens.forEach(s => s.geometry.dispose()); group.traverse(o => { if (o instanceof THREE.InstancedMesh) o.dispose(); }); } };
}
