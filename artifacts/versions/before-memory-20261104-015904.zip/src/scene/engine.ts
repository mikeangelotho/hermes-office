import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import type { OfficeAgent } from '../domain/types.ts';
import { Assets, createRoom } from './room.ts';
import { Character } from './character.ts';
import { createCourtyard } from './courtyard.ts';
import { framingFor, pixelRatioFor } from './camera.ts';
import { PALETTE as P } from './palette.ts';
import { createFiberField } from './fibers.ts';
import { createSpatialGlass } from './spatial-glass.ts';
import { createDataTrails, type TrailSubject } from './data-trails.ts';

export interface OfficeEngine {
  update(agents: OfficeAgent[]): void;
  select(id: string | null): void;
  setNight(value: boolean): void;
  setMotion(value: boolean): void;
  zoom(direction: number): void;
  reset(): void;
  dispose(): void;
}
export function createOffice(canvas: HTMLCanvasElement, options: { onSelect: (id: string | null) => void; onError: (message: string) => void; interactive: boolean }): OfficeEngine {
  const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true, powerPreference: 'low-power' });
  renderer.info.autoReset = false;
  renderer.setClearColor(0, 0); renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.1;
  renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFShadowMap; renderer.shadowMap.autoUpdate = false;
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(P.void);
  scene.fog = new THREE.Fog(P.void,45,110);
  const camera = new THREE.OrthographicCamera(-10, 10, 8, -8, .1, 100);
  const initialPosition = new THREE.Vector3(16, 13, 19); const target = new THREE.Vector3(0, .7, 0);
  camera.position.copy(initialPosition); camera.lookAt(target);
  const controls = new OrbitControls(camera, canvas);
  controls.target.copy(target); controls.enablePan = false; controls.enableDamping = true; controls.dampingFactor = .12;
  controls.minPolarAngle = .55; controls.maxPolarAngle = 1.25;
  const angle = Math.atan2(16, 19); controls.minAzimuthAngle = angle - .85; controls.maxAzimuthAngle = angle + .85;
  controls.minZoom = .7; controls.maxZoom = 2.1; controls.enabled = options.interactive; controls.update();
  const ambient = new THREE.HemisphereLight(P.ice, P.metal, 1.35); scene.add(ambient);
  const sun = new THREE.DirectionalLight(P.ice, 1.65); sun.position.set(-1, 11, 1); sun.castShadow = true;
  sun.shadow.mapSize.set(1536, 1536); sun.shadow.camera.left = -12; sun.shadow.camera.right = 12; sun.shadow.camera.top = 10; sun.shadow.camera.bottom = -10;
  sun.shadow.camera.near = .1; sun.shadow.camera.far = 35; sun.shadow.normalBias = .045; sun.shadow.bias = -.00025; sun.shadow.radius = 3; scene.add(sun);
  const a = new Assets(); const courtyard = createCourtyard(a); scene.add(courtyard.group);
  const room = createRoom(a); scene.add(room.group);
  const fibers = createFiberField(); scene.add(fibers.group);
  const glass = createSpatialGlass(renderer,camera,[room.group,courtyard.group],a.glass);
  const trails = createDataTrails(10);scene.add(trails.points);
  let trailSubjects: TrailSubject[] = [];const towardCamera = new THREE.Vector3();
  const shadowTexture = a.texture(64, 64, ctx => { const gradient = ctx.createRadialGradient(32, 32, 2, 32, 32, 32); gradient.addColorStop(0, 'rgba(0,3,15,.85)'); gradient.addColorStop(1, 'rgba(0,3,15,0)'); ctx.fillStyle = gradient; ctx.fillRect(0, 0, 64, 64); });
  // A single soft shadow anchors the diorama without another render target.
  const groundMaterial = new THREE.MeshBasicMaterial({ map: shadowTexture, transparent: true, opacity: .2, depthWrite: false });
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(23, 20), groundMaterial); ground.rotation.x = -Math.PI / 2; ground.position.y = -.43; scene.add(ground);
  const characters = new Map<string, Character>();
  let selected: string | null = null, disposed = false, motion = true, intersecting = true, dirty = true;
  const media = window.matchMedia('(prefers-reduced-motion: reduce)');
  const reduced = () => media.matches || !motion;
  const raycaster = new THREE.Raycaster(); const pointer = new THREE.Vector2();
  const cursor = new THREE.Vector2(); let cursorActive = false;
  let visualTime = 0;
  let pointerDown = { x: 0, y: 0 }; let lastFrame = 0; let frames = 0; let statsAt = performance.now();
  function resize() {
    if (disposed) return; const rect = canvas.getBoundingClientRect(); if (rect.width <= 0 || rect.height <= 0) return;
    cursorActive = false;
    const framing = framingFor(rect.width, rect.height);
    camera.left = -framing.width / 2; camera.right = framing.width / 2; camera.top = framing.height / 2; camera.bottom = -framing.height / 2; camera.updateProjectionMatrix();
    renderer.setPixelRatio(pixelRatioFor(rect.width, rect.height, window.devicePixelRatio || 1)); renderer.setSize(rect.width, rect.height, false);glass.resize(rect.width,rect.height); dirty = true;
  }
  const resizeObserver = new ResizeObserver(resize); resizeObserver.observe(canvas);
  const intersectionObserver = new IntersectionObserver(entries => { intersecting = entries[0].isIntersecting; schedule(); }, { threshold: .01 }); intersectionObserver.observe(canvas);
  function frame(now: number) {
    if (disposed) return;
    // Thirty deliberate frames per second suits the retro art and halves background work.
    if (now - lastFrame < 1000 / 30 - 1) return;
    const dt = Math.min((now - lastFrame) / 1000 || 0, .06); lastFrame = now;
    const cameraChanged = controls.update(); const moving = [...characters.values()].some(c => c.path.length > 0);
    if (reduced() && !dirty && !cameraChanged && !moving) return;
    if (!reduced()) visualTime += dt;
    fibers.tick(visualTime, reduced()); a.tickHolograms(visualTime, reduced());
    canvas.dataset.fiberTime = visualTime.toFixed(3);
    let firstCouch: Character | undefined; let following = 0;
    const activeCursor = cursorActive && !reduced() ? cursor : null;
    characters.forEach(c => {
      const tracking = c.lookAtCursor(activeCursor, camera);
      c.tick(visualTime, dt, reduced());
      if (c.seat.kind === 'couch' && !c.path.length) firstCouch ??= c;
      if (tracking) following++;
    });
    canvas.dataset.gazeTracking = String(following);
    canvas.dataset.gazeYaw = (firstCouch?.head.rotation.y ?? 0).toFixed(4);
    canvas.dataset.gazePitch = (firstCouch?.head.rotation.x ?? 0).toFixed(4);
    camera.getWorldDirection(towardCamera).negate();trails.setView(towardCamera,renderer.getPixelRatio());
    trails.update(visualTime,trailSubjects,reduced());
    renderer.info.reset();
    const capture = glass.render(visualTime,dirty || cameraChanged);
    renderer.render(scene, camera); dirty = false; frames++;
    canvas.dataset.glassReady = String(a.glass.ready.value);canvas.dataset.glassPixels = String(capture.pixels);
    canvas.dataset.dataTrails = String(trails.active);canvas.dataset.glassDrawCalls = String(capture.calls);
    if (now - statsAt >= 1000) { canvas.dataset.fps = String(Math.round(frames * 1000 / (now - statsAt))); canvas.dataset.drawCalls = String(renderer.info.render.calls); canvas.dataset.triangles = String(renderer.info.render.triangles-capture.triangles);canvas.dataset.totalTriangles = String(renderer.info.render.triangles); frames = 0; statsAt = now; }
  }
  function schedule() { if (disposed) return; lastFrame = 0; dirty = true; renderer.setAnimationLoop(!document.hidden && intersecting ? frame : null); }
  function onVisibility() { if (document.hidden) cursorActive = false; schedule(); }
  function onMediaChange() { if (reduced()) cursorActive = false; controls.enableDamping = !reduced(); dirty = true; }
  function onLeave() { cursorActive = false; }
  function onMove(e: PointerEvent) {
    if (reduced() || e.pointerType === 'touch' || e.buttons) { onLeave(); return; }
    const rect = canvas.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) { onLeave(); return; }
    cursor.set((e.clientX - rect.left) / rect.width * 2 - 1, -(e.clientY - rect.top) / rect.height * 2 + 1);
    cursorActive = true;
    // Normal animation already renders at 30Hz. Do not mark glass capture dirty on pointer movement.
  }
  function onDown(e: PointerEvent) { onLeave(); pointerDown = { x: e.clientX, y: e.clientY }; }
  function onUp(e: PointerEvent) {
    if (!options.interactive || Math.hypot(e.clientX - pointerDown.x, e.clientY - pointerDown.y) > 7) return;
    const rect = canvas.getBoundingClientRect(); pointer.set((e.clientX - rect.left) / rect.width * 2 - 1, -(e.clientY - rect.top) / rect.height * 2 + 1);
    raycaster.setFromCamera(pointer, camera); const hit = raycaster.intersectObjects([...characters.values()].map(c => c.pick), false)[0];
    options.onSelect(hit ? String(hit.object.userData.agentId) : null);
  }
  function onKey(e: KeyboardEvent) {
    if (!options.interactive) return;
    if (e.key === '+' || e.key === '=') { api.zoom(1); e.preventDefault(); }
    if (e.key === '-') { api.zoom(-1); e.preventDefault(); }
    if (e.key === 'Home') { api.reset(); e.preventDefault(); }
    if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') { const spherical = new THREE.Spherical().setFromVector3(camera.position.clone().sub(controls.target)); spherical.theta += e.key === 'ArrowLeft' ? -.1 : .1; camera.position.copy(controls.target).add(new THREE.Vector3().setFromSpherical(spherical)); dirty = true; e.preventDefault(); }
  }
  function onContextLost(e: Event) { e.preventDefault(); renderer.setAnimationLoop(null); options.onError('The 3D view was interrupted. Reload to restore it; your roster is still available.'); }
  controls.addEventListener('change', () => { dirty = true; });
  canvas.addEventListener('pointerdown', onDown); canvas.addEventListener('pointerup', onUp); canvas.addEventListener('keydown', onKey); canvas.addEventListener('webglcontextlost', onContextLost);
  if (options.interactive) { canvas.addEventListener('pointermove', onMove, { passive: true }); canvas.addEventListener('pointerleave', onLeave); canvas.addEventListener('pointercancel', onLeave); }
  document.addEventListener('visibilitychange', onVisibility); media.addEventListener('change', onMediaChange);
  const api: OfficeEngine = {
    update(agents) {
      const ids = new Set(agents.map(x => x.id));let rosterChanged = false;
      characters.forEach((c, id) => { if (!ids.has(id)) { rosterChanged = true;scene.remove(c.root); c.dispose(); characters.delete(id); } });
      agents.slice(0, 10).forEach((agent, i) => { const existing = characters.get(agent.id); if (existing) existing.update(agent, i, reduced()); else { rosterChanged = true;const c = new Character(a, agent, i, shadowTexture); characters.set(agent.id, c); scene.add(c.root); } });
      room.screens.forEach((screen, i) => screen.material = agents[i] && ['working', 'waiting', 'blocked'].includes(agents[i].state) ? room.screenOn : room.screenOff);
      if(rosterChanged){glass.setSources([room.group,courtyard.group,...[...characters.values()].map(c=>c.root)]);trailSubjects=[...characters.values()].map(c=>({head:c.head,hands:c.hands}));}
      api.select(selected); dirty = true; canvas.dataset.agents = String(characters.size);
    },
    select(id) { selected = id; characters.forEach(c => c.select(c.agent.id === id)); dirty = true; },
    setNight(value) {
      const sky = value ? P.night : P.void;
      (scene.background as THREE.Color).set(sky);
      (scene.fog as THREE.Fog).color.set(sky);
      ambient.color.set(value ? P.azure : P.ice); ambient.intensity = value ? .9 : 1.35; sun.color.set(value ? P.azure : P.ice); sun.intensity = value ? 1.0 : 1.65; renderer.toneMappingExposure = value ? .9 : 1.1; renderer.shadowMap.needsUpdate = true; dirty = true; },
    setMotion(value) { motion = value; if (reduced()) cursorActive = false; controls.enableDamping = !reduced(); if (reduced()) characters.forEach(c => { c.path = []; c.root.position.set(c.seat.x, 0, c.seat.z); c.tick(0, 0, true); }); dirty = true; },
    zoom(direction) { camera.zoom = THREE.MathUtils.clamp(camera.zoom * (direction > 0 ? 1.16 : 1 / 1.16), .7, 2.1); camera.updateProjectionMatrix(); dirty = true; },
    reset() { camera.position.copy(initialPosition); camera.zoom = 1; controls.target.copy(target); camera.updateProjectionMatrix(); controls.update(); dirty = true; },
    dispose() {
      disposed = true; renderer.setAnimationLoop(null); resizeObserver.disconnect(); intersectionObserver.disconnect(); controls.dispose();
      document.removeEventListener('visibilitychange', onVisibility); media.removeEventListener('change', onMediaChange);
      canvas.removeEventListener('pointermove', onMove); canvas.removeEventListener('pointerleave', onLeave); canvas.removeEventListener('pointercancel', onLeave);
      canvas.removeEventListener('pointerdown', onDown); canvas.removeEventListener('pointerup', onUp); canvas.removeEventListener('keydown', onKey); canvas.removeEventListener('webglcontextlost', onContextLost);
      characters.forEach(c => c.dispose()); characters.clear(); glass.dispose();trails.dispose();room.dispose(); courtyard.dispose(); fibers.dispose(); ground.geometry.dispose(); groundMaterial.dispose(); a.dispose(); renderer.dispose(); renderer.forceContextLoss();
    },
  };
  resize(); renderer.shadowMap.needsUpdate = true; schedule(); return api;
}
