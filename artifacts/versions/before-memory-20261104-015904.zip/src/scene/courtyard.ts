import * as THREE from 'three';
import { Assets } from './room.ts';
import { PALETTE as P } from './palette.ts';

/** The office sits in a small park. Decoration is static and instanced by material. */
export function createCourtyard(assets: Assets): { group: THREE.Group; dispose: () => void } {
  const group = new THREE.Group();
  const batches = new Map<string, { kind: string; color: string; matrices: THREE.Matrix4[]; shadow: boolean }>();
  const transform = new THREE.Object3D();
  const part = (color: string, size: number[], position: number[], kind = 'box', rotation = 0, shadow = true) => {
    transform.position.set(position[0], position[1], position[2]); transform.scale.set(size[0], size[1], size[2]); transform.rotation.set(0,rotation,0); transform.updateMatrix();
    const key = `${kind}:${color}:${shadow}`;
    const batch = batches.get(key) ?? { kind, color, matrices: [], shadow };
    batch.matrices.push(transform.matrix.clone()); batches.set(key,batch);
  };
  part(P.black,[280,.08,280],[0,-.49,0],'box',0,false);
  // Broad lawns, an entry path and a quiet terrace around the cutaway office.
  for (let i=0;i<10;i++) {
    const x = i%2 ? -13 : 13, z = -12+Math.floor(i/2)*6;
    part(i%3 ? P.foundation : P.floor,[4.5,.012,4],[x,-.438,z],'box',0,false);
  }
  part(P.floor,[34,.035,2.5],[0,-.425,7.7],'box',0,false);
  part(P.floor,[2.65,.035,27],[0,-.425,19.7],'box',0,false);
  for (let i=0;i<28;i++) part(P.frame,[.86,.025,.82],[-13.5+i,-.397,7.7+(i%2 ? .3 : -.3)],'box',0,false);
  for (let i=0;i<12;i++) part(P.frame,[1.05,.025,.83],[i%2 ? .53 : -.53,-.397,9.2+i*.95],'box',0,false);
  for (const side of [-1,1]) part(P.metal,[.14,.08,27],[side*1.45,-.405,19.7],'box',0,false);

  const trees: [number,number,number][] = [[-10,-9,1.1],[-6.5,-11,1],[-2,-10,.9],[3,-11,1.1],[8,-10,1.05],[12,-7,1],[-13,-4,1.25],[-13,1,1],[-12,8,1.05],[13,3,1.2],[13,10,1],[-10,14,1.1],[9,16,1.2],[-16,13,1.25],[17,-2,1.15],[-14,-13,1.3]];
  trees.forEach(([x,z,s],i) => {
    part(P.metal,[.36*s,2.5*s,.36*s],[x,.8*s,z],'cylinder');
    part([P.leaf,P.leafLight,P.frame][i%3],[3.2*s,2.8*s,3.2*s],[x,2.05*s,z],'cone',i*.4);
    part([P.leafLight,P.frame,P.leaf][i%3],[2.5*s,2.5*s,2.5*s],[x,3.25*s,z],'cone',i*.4);
  });
  for (let i=0;i<16;i++) {
    const side=i%2 ? -1 : 1, z=-5+Math.floor(i/2)*1.6;
    part(i%3 ? P.leaf : P.leafLight,[1.2,.75,1.1],[side*10.3,-.02,z],'leaf',i*.6);
  }
  // Garden benches frame the office rather than obstructing its inhabitants.
  for (const side of [-1,1]) {
    const x=side*10, z=5.6;
    for (const dz of [-.3,0,.3]) part(P.furniture,[2.75,.1,.22],[x,.2,z+dz]);
    for (const y of [.58,.82]) part(P.furniture,[2.75,.15,.1],[x,y,z-.42]);
    for (const dx of [-1.05,1.05]) { part(P.metal,[.1,.7,.12],[x+dx,-.08,z]); part(P.metal,[.1,1.15,.12],[x+dx,.15,z-.42]); }
  }
  for (let i=0;i<12;i++) {
    const side=i%2 ? -1 : 1, x=side*(8.6+(i%3)*.18), z=-6+Math.floor(i/2)*2.1;
    part(P.frame,[.35,.15,.27],[x,-.35,z],'leaf',i*.9);
    const flowerX=side*(9+(i%2)*.4), flowerZ=z+.4;
    part(P.leaf,[.045,.31,.045],[flowerX,-.26,flowerZ]);
    part(i%2 ? P.azure : P.blue,[.19,.2,.19],[flowerX,-.07,flowerZ],'leaf');
  }
  for (const side of [-1,1]) {
    const x=side*8.4,z=8;
    part(P.metal,[.09,2.8,.09],[x,.96,z],'cylinder');
    part(P.metal,[.5,.08,.5],[x,2.4,z]);
    part(P.ice,[.32,.42,.32],[x,2.14,z]);
    part(P.metal,[.47,.08,.47],[x,1.9,z]);
  }
  for (const batch of batches.values()) {
    const mesh = new THREE.InstancedMesh(assets.geometry(batch.kind), assets.material(batch.color, batch.kind), batch.matrices.length);
    batch.matrices.forEach((matrix,i)=>mesh.setMatrixAt(i,matrix)); mesh.castShadow=batch.shadow; mesh.receiveShadow=true; mesh.computeBoundingSphere(); group.add(mesh);
  }
  return { group, dispose: () => { group.traverse(node => { if (node instanceof THREE.InstancedMesh) node.dispose(); }); } };
}
