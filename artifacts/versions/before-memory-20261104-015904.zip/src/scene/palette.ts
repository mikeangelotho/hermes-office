/** Portfolio source: mikeangeloart/src/three/SceneManager.tsx (#3366ff).
 * Black glass + blue-white light; no warm diorama materials or imported brand assets.
 */
export const PALETTE = {
  void: '#02040b', night: '#010207', black: '#050a16',
  floor: '#0c1832', floorAlt: '#101e3d', foundation: '#060d1e',
  wall: '#163164', frame: '#244b91', glass: '#2a5aa3',
  furniture: '#234783', cushion: '#315ca2', metal: '#19325b',
  blue: '#3366ff', azure: '#5e8fff', ice: '#b5d2ff',
  face: '#86aef2', hair: '#142d5d', leaf: '#254c8d', leafLight: '#3869b1',
  muted: '#335580', screen: '#091b3f',
} as const;
export const AGENT_HUES = ['#3366ff', '#5788e8', '#719de6', '#365cc1', '#8bb3ef', '#4377cf', '#6c8de0', '#2e54a8', '#9abff4', '#5279bc'] as const;
