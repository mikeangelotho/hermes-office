import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { Assets } from '../src/scene/room.ts';
import { Character } from '../src/scene/character.ts';
import { ROOM } from '../src/scene/layout.ts';
import type { AgentState, OfficeAgent } from '../src/domain/types.ts';
const agent = (state: AgentState): OfficeAgent => ({ id: 'studio-engineer', name: 'Engineer', role: 'Engineer', team: 'studio', state, observedAt: new Date().toISOString(), activity: 'Fixture only' });

test('all couch poses keep thighs above cushions and calves in front, with grounded feet', () => {
  const assets = new Assets(), texture = new THREE.Texture();
  try {
    for (const state of ['idle', 'paused', 'offline'] as const) for (let i = 0; i < ROOM.capacity; i++) {
      const c = new Character(assets, agent(state), i, texture);
      try {
        c.tick(0, 0, true); c.root.updateMatrixWorld(true);
        for (let side = 0; side < 2; side++) {
          const thigh = new THREE.Box3().setFromObject(c.thighs[side].children[0]);
          const calf = new THREE.Box3().setFromObject(c.calves[side]);
          assert.ok(thigh.min.y >= .615, `seat ${i} ${state}: thigh penetrates cushion (${thigh.min.y})`);
          assert.ok(calf.min.z > 4.1, `seat ${i} ${state}: lower leg intersects cushion (${calf.min.z})`);
          assert.ok(calf.min.y >= .035 && calf.min.y <= .085, `seat ${i}: foot must rest on floor (${calf.min.y})`);
        }
      } finally { c.dispose(); }
    }
  } finally { assets.dispose(); texture.dispose(); }
});

test('desk poses remain above chair seats, face screens, and place hands at keyboard height', () => {
  const assets = new Assets(), texture = new THREE.Texture();
  try {
    for (let i = 0; i < ROOM.capacity; i++) {
      const c = new Character(assets, agent('working'), i, texture);
      try {
        c.tick(0, 0, true); c.root.updateMatrixWorld(true);
        const thigh = new THREE.Box3().setFromObject(c.thighs[0].children[0]);
        const calf = new THREE.Box3().setFromObject(c.calves[0]);
        assert.ok(thigh.min.y >= .605, 'thigh must not penetrate chair');
        assert.ok(calf.min.y >= .035 && calf.min.y <= .085, 'desk feet must be grounded');
        const hands = (c as Character & { hands?: THREE.Mesh[] }).hands;
        assert.equal(hands?.length, 2, 'typing needs articulated forearms and hands');
        for (const hand of hands ?? []) {
          const position = hand.getWorldPosition(new THREE.Vector3());
          assert.ok(position.y >= 1.12 && position.y <= 1.25, `typing hand is not at keyboard height (${position.y})`);
          assert.ok(Math.abs(position.z - (c.seat.z - .75)) < .2, 'typing hands must reach the keyboard');
        }
      } finally { c.dispose(); }
    }
  } finally { assets.dispose(); texture.dispose(); }
});
