import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import {Assets} from '../src/scene/room.ts';
import {Character} from '../src/scene/character.ts';
import type {OfficeAgent} from '../src/domain/types.ts';
const agent:OfficeAgent={id:'studio-engineer',name:'Engineer',role:'Engineer',team:'studio',state:'idle',observedAt:new Date().toISOString(),activity:'Fixture only'};
test('memory figures use adult-scale faceted heads and tapered limbs rather than toy block heads',()=>{
  const assets=new Assets(),texture=new THREE.Texture();
  try{for(let i=0;i<10;i++){
    const c=new Character(assets,agent,i,texture);
    try{
      c.root.updateMatrixWorld(true);
      const head=new THREE.Box3().setFromObject(c.head).getSize(new THREE.Vector3());
      const chest=new THREE.Box3().setFromObject(c.body.children[0]).getSize(new THREE.Vector3());
      assert.ok(head.x/chest.x<.63,`head is still oversized (${head.x/chest.x})`);
      assert.ok(head.y<.36,'head must not have a block hat silhouette');
      assert.notEqual((c.thighs[0].children[0] as THREE.Mesh).geometry.type,'BoxGeometry','limbs need tapered human silhouettes');
    }finally{c.dispose();}
  }}finally{assets.dispose();texture.dispose();}
});
