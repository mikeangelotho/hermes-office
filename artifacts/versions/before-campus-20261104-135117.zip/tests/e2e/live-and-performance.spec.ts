import { test, expect } from '@playwright/test';

test('live mode returns real profile observations and rejects writes', async ({ page, request }) => {
  const response = await request.get('/api/office');
  expect(response.status()).toBe(200);
  const snapshot = await response.json();
  expect(snapshot.schemaVersion).toBe(1);
  expect(snapshot.mode).toBe('live');
  expect(snapshot.agents.length).toBeGreaterThan(0);
  expect(response.headers()['cache-control']).toBe('no-store');
  const denied = await request.post('/api/office', { data: { command: 'start' } });
  expect(denied.status()).toBe(405);
  await page.goto('/');
  await page.getByRole('button', {name:'Open status',exact:true}).click();
  await expect(page.getByRole('button', { name: 'Live', exact: true })).toHaveAttribute('aria-pressed', 'true');
  await page.keyboard.press('Escape');
  await page.getByRole('button', {name:'Open team',exact:true}).click();
  await expect(page.getByTestId('agent-row')).toHaveCount(snapshot.agents.filter((a: { team: string }) => a.team === 'studio').length);
  await expect(page.getByText('Simulated activity', { exact: true })).toHaveCount(0);
});

test('the ten-agent room stays within its draw and geometry budget', async ({ page }) => {
  await page.goto('/?source=demo');
  await expect(page.getByTestId('scene-status')).toHaveText('ready', { timeout: 20000 });
  await page.getByRole('button', {name:'Open team',exact:true}).click();
  await page.getByRole('button', { name: /^Development\b/ }).click();
  await page.keyboard.press('Escape');
  const canvas = page.getByTestId('scene-canvas');
  await expect(canvas).toHaveAttribute('data-agents', '10');
  await expect.poll(async () => Number(await canvas.getAttribute('data-triangles'))).toBeGreaterThan(0);
  expect(Number(await canvas.getAttribute('data-triangles'))).toBeLessThan(18000);
  expect(Number(await canvas.getAttribute('data-draw-calls'))).toBeLessThan(360);
  await page.getByRole('button', {name:'Open view controls'}).click();
  await page.getByRole('button', { name: 'Pause animation' }).click();
  await expect(page.getByRole('button', { name: 'Resume animation' })).toBeVisible();
});
