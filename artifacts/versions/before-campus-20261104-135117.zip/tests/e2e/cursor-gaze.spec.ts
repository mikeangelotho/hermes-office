import {test,expect} from '@playwright/test';

test('couch heads respond to real mouse movement in both axes',async({page})=>{
  await page.goto('/?source=demo');
  const canvas=page.getByTestId('scene-canvas');
  await expect(page.getByTestId('scene-status')).toHaveText('ready',{timeout:20000});
  await page.mouse.move(80,720);
  await expect.poll(async()=>Number(await canvas.getAttribute('data-gaze-tracking'))).toBeGreaterThan(0);
  await expect.poll(async()=>Math.abs(Number(await canvas.getAttribute('data-gaze-yaw')))).toBeGreaterThan(.02);
  await page.waitForTimeout(250);
  const left=Number(await canvas.getAttribute('data-gaze-yaw')),low=Number(await canvas.getAttribute('data-gaze-pitch'));
  await page.mouse.move(1360,180);
  await expect.poll(async()=>Number(await canvas.getAttribute('data-gaze-yaw')),{timeout:10000}).toBeGreaterThan(left+.1);
  await expect.poll(async()=>Number(await canvas.getAttribute('data-gaze-pitch')),{timeout:10000}).toBeLessThan(low-.04);
  expect(Math.abs(Number(await canvas.getAttribute('data-gaze-yaw')))).toBeLessThanOrEqual(.751);
  await page.getByRole('toolbar',{name:'Office controls'}).hover();
  await expect(canvas).toHaveAttribute('data-gaze-tracking','0');
  await expect.poll(async()=>Math.abs(Number(await canvas.getAttribute('data-gaze-yaw'))),{timeout:10000}).toBeLessThan(.02);
});

test('paused, reduced-motion and embedded views ignore cursor tracking',async({page})=>{
  await page.goto('/?source=demo');
  const canvas=page.getByTestId('scene-canvas');
  await expect(page.getByTestId('scene-status')).toHaveText('ready',{timeout:20000});
  await page.getByRole('button',{name:'Open view controls',exact:true}).click();
  await page.getByRole('button',{name:'Pause animation',exact:true}).click();
  await page.keyboard.press('Escape');await page.mouse.move(1200,200);
  await expect(canvas).toHaveAttribute('data-gaze-tracking','0');
  await page.emulateMedia({reducedMotion:'reduce'});await page.reload();
  await expect(page.getByTestId('scene-status')).toHaveText('ready',{timeout:20000});
  await page.mouse.move(80,720);await page.mouse.move(1360,180);
  await expect(canvas).toHaveAttribute('data-gaze-tracking','0');
  await page.emulateMedia({reducedMotion:'no-preference'});await page.goto('/?embed=1');
  await expect(page.getByTestId('scene-status')).toHaveText('ready',{timeout:20000});
  await page.mouse.move(80,720);await page.mouse.move(1360,180);
  await expect(canvas).toHaveAttribute('data-gaze-tracking','0');
  await expect(page.locator('button,input,dialog')).toHaveCount(0);
});
