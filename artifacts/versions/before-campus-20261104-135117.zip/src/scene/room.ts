import * as THREE from 'three';
import { PALETTE as P } from './palette.ts';
import { hologramMaterial, type SurfaceRole } from './hologram.ts';
import type { GlassUniforms } from './spatial-glass.ts';

/** Shared primitives and instanced static geometry keep the room cheap to draw. */
export class Assets {
  geometries = new Map<string, THREE.BufferGeometry>();
  materials = new Map<string, THREE.MeshLambertMaterial>();
  textures = new Set<THREE.Texture>();
  private hologramTime = { value: 0 };
  readonly glass: GlassUniforms = { texture: { value: null }, viewport: { value: new THREE.Vector2(1,1) }, ready: { value: 0 } };
  tickHolograms(time: number, reduced: boolean) { if (!reduced) this.hologramTime.value = time; }
  geometry(kind = 'box') {
    if (!this.geometries.has(kind)) this.geometries.set(kind, kind === 'torso' ? new THREE.CylinderGeometry(.5, .36, 1, 8) : kind === 'limb' ? new THREE.CylinderGeometry(.5, .39, 1, 8) : kind === 'head' ? new THREE.SphereGeometry(.5, 8, 6) : kind === 'hand' ? new THREE.IcosahedronGeometry(.5, 0) : kind === 'cylinder' ? new THREE.CylinderGeometry(.5, .5, 1, 8) : kind === 'cone' ? new THREE.ConeGeometry(.5, 1, 6) : kind === 'leaf' ? new THREE.IcosahedronGeometry(.5, 0) : kind === 'sphere' ? new THREE.SphereGeometry(.5, 8, 6) : new THREE.BoxGeometry(1, 1, 1));
    return this.geometries.get(kind)!;
  }
  material(color: string, kind = 'box', role: SurfaceRole = 'environment') {
    const key = `${role}:${color}:${kind}`;
    if (!this.materials.has(key)) this.materials.set(key, hologramMaterial(color, kind, this.hologramTime, role, this.glass));
    return this.materials.get(key)!;
  }
  mesh(color: string, size: number[], position: number[], kind = 'box', parent?: THREE.Object3D, role: SurfaceRole = 'environment') {
    const mesh = new THREE.Mesh(this.geometry(kind), this.material(color, kind, role));
    mesh.scale.set(size[0], size[1], size[2]); mesh.position.set(position[0], position[1], position[2]);
    mesh.castShadow = true; mesh.receiveShadow = true; parent?.add(mesh); return mesh;
  }
  texture(width: number, height: number, paint: (ctx: CanvasRenderingContext2D) => void) {
    const canvas = document.createElement('canvas'); canvas.width = width; canvas.height = height;
    paint(canvas.getContext('2d')!); const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace; texture.magFilter = THREE.NearestFilter; texture.minFilter = THREE.LinearFilter;
    this.textures.add(texture); return texture;
  }
  dispose() { this.geometries.forEach(g => g.dispose()); this.materials.forEach(m => m.dispose()); this.textures.forEach(t => t.dispose()); }
}
interface StaticPart { color: string; kind: string; matrix: THREE.Matrix4; }
export interface RoomModel { group: THREE.Group; screens: THREE.Mesh[]; screenOn: THREE.MeshLambertMaterial; screenOff: THREE.MeshLambertMaterial; dispose: () => void; }

export function createRoom(a: Assets): RoomModel {
  const group=new THREE.Group();group.name='reconstructed-office';const parts:StaticPart[]=[];const transform=new THREE.Object3D();
  const part=(color:string,size:number[],at:number[],kind='box',rotation=0)=>{
    transform.position.set(at[0],at[1],at[2]);transform.scale.set(size[0],size[1],size[2]);transform.rotation.set(0,rotation,0);transform.updateMatrix();parts.push({color,kind,matrix:transform.matrix.clone()});
  };
  const leg=(x:number,z:number,h:number)=>part(P.metal,[.035,h,.035],[x,h/2,z]);
  // No toy plinth or checkerboard: a thin surface disappearing into scan-space.
  part(P.floor,[15.05,.035,12.05],[0,.018,0]);
  // Only fragments of the original envelope survive. The room is implied, not boxed in.
  for(const [x,h] of [[-7.3,4.6],[-3.1,3.2],[1.5,5.4],[6.9,3.9]]){
    part(P.frame,[.035,h,.045],[x,h/2,-5.9]);
    part(P.frame,[1.1,.025,.04],[x+.5,h*.75,-5.9]);
  }
  for(const x of [-1.55,1.65,4.85]){
    part(P.glass,[2.48,1.72,.025],[x,2.46,-5.74]);
    part(P.frame,[2.51,.025,.035],[x,3.32,-5.72]);
  }
  const screenTexture=a.texture(128,80,ctx=>{
    ctx.fillStyle=P.screen;ctx.fillRect(0,0,128,80);
    for(let i=0;i<9;i++){ctx.fillStyle=i%4===0?P.ice:P.azure;ctx.fillRect(9+i%2*6,10+i*7,22+(i*13)%74,1);}
  });
  const screenOn=a.material(P.azure,'plane','screen');screenOn.map=screenTexture;screenOn.emissiveMap=screenTexture;
  const screenOff=a.material(P.metal,'plane');const screens:THREE.Mesh[]=[];
  for(let i=0;i<10;i++){
    const x=-5.1+i%5*2.55,z=i<5?-3.2:-.3;
    part(P.glass,[1.9,.065,1.12],[x,1.065,z]);
    for(const dx of [-.79,.79])for(const dz of [-.43,.43])leg(x+dx,z+dz,1.03);
    part(P.metal,[.49,.025,.27],[x,1.145,z-.17]);part(P.metal,[.035,.3,.035],[x,1.31,z-.26]);
    part(P.metal,[1.04,.65,.045],[x,1.72,z-.3]);
    const screen=new THREE.Mesh(new THREE.PlaneGeometry(.96,.58),screenOff);screen.position.set(x,1.73,z-.268);group.add(screen);screens.push(screen);
    part(P.muted,[.67,.018,.23],[x,1.165,z+.3]);
    part(P.metal,[.61,.09,.6],[x,.55,z+1.05]);part(P.metal,[.60,.58,.045],[x,.89,z+1.33]);
    leg(x,z+1.05,.5);part(P.metal,[.61,.035,.08],[x,.09,z+1.05]);part(P.metal,[.08,.035,.57],[x,.09,z+1.05]);
  }
  // Preserve seat surfaces and rig clearance; strip the domestic rug/plant/book styling.
  for(const side of [-1,1]){
    const x=side*3.7;
    part(P.furniture,[5.1,.13,1.05],[x,.25,3.56]);part(P.furniture,[5.35,.61,.19],[x,.75,3.12]);
    for(const dx of [-2.6,2.6])part(P.furniture,[.15,.53,1.1],[x+dx,.63,3.58]);
    for(let i=0;i<5;i++)part(P.cushion,[.96,.25,.88],[x-2+i,.49,3.66]);
  }
  const batches=new Map<string,StaticPart[]>();
  for(const item of parts){const key=`${item.kind}:${item.color}`;const batch=batches.get(key)??[];batch.push(item);batches.set(key,batch);}
  for(const items of batches.values()){
    const mesh=new THREE.InstancedMesh(a.geometry(items[0].kind),a.material(items[0].color,items[0].kind),items.length);
    items.forEach((item,i)=>mesh.setMatrixAt(i,item.matrix));mesh.receiveShadow=true;mesh.computeBoundingSphere();group.add(mesh);
  }
  return {group,screens,screenOn,screenOff,dispose:()=>{screens.forEach(s=>s.geometry.dispose());group.traverse(o=>{if(o instanceof THREE.InstancedMesh)o.dispose();});}};
}

