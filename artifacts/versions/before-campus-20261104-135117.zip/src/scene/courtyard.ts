import * as THREE from 'three';
import {Assets} from './room.ts';
import {PALETTE as P} from './palette.ts';
import {scanMaterial} from './memory-field.ts';

/** The residual architecture of a memory, not a landscaped miniature. */
export function createCourtyard(assets:Assets){
  const group=new THREE.Group();group.name='memory-void';const time={value:0};
  const base=assets.mesh(P.black,[280,.025,280],[0,-.055,0],'box',group);base.castShadow=false;
  const transform=new THREE.Object3D(),ribs=new THREE.InstancedMesh(assets.geometry(),assets.material(P.frame),12);
  for(let i=0;i<12;i++){
    const x=-16+i*2.9,h=1.4+(i%4)*1.15;
    transform.position.set(x,h*.5,-10.8-(i%3)*.4);transform.scale.set(.025,h,.035);transform.updateMatrix();ribs.setMatrixAt(i,transform.matrix);
  }ribs.computeBoundingSphere();group.add(ribs);
  let seed=81751;const random=()=>{seed=(Math.imul(seed,1664525)+0x3c6ef35f)>>>0;return seed/4294967296;};
  const count=20000,positions=new Float32Array(count*3),seeds=new Float32Array(count);
  for(let i=0;i<count;i++){
    let x=(random()-.5)*44,z=(random()-.5)*40,y=-.025+random()*.025;
    if(i<14000){if(Math.abs(x)<7.9&&Math.abs(z)<6.4)z=(z<0?-1:1)*(7+random()*12);}
    else {y=random()*10.5;if(i%3===0){z=-12.5;x=(random()-.5)*36;}else{x=i%3===1?-18:18;z=-12+random()*30;}}
    positions.set([x,y,z],i*3);seeds[i]=random();
  }
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.BufferAttribute(positions,3));geometry.setAttribute('aSeed',new THREE.BufferAttribute(seeds,1));geometry.computeBoundingSphere();
  const material=scanMaterial(time,.35);group.add(new THREE.Points(geometry,material));
  const streaks:number[]=[];
  for(let i=14000;i<count;i+=29){const at=i*3;streaks.push(positions[at],positions[at+1],positions[at+2],positions[at],positions[at+1]+.3+seeds[i]*1.7,positions[at+2]);}
  const lineGeometry=new THREE.BufferGeometry();lineGeometry.setAttribute('position',new THREE.Float32BufferAttribute(streaks,3));
  const lineMaterial=new THREE.LineBasicMaterial({color:P.azure,transparent:true,opacity:.085,depthWrite:false,blending:THREE.AdditiveBlending});lineMaterial.userData.captureMemory=true;
  group.add(new THREE.LineSegments(lineGeometry,lineMaterial));let disposed=false;
  return {group,pointCount:count,tick(value:number,reduced:boolean){if(!disposed&&!reduced)time.value=value;},setPixelRatio(value:number){material.uniforms.uPixelRatio.value=THREE.MathUtils.clamp(value,1,1.65);},dispose(){if(disposed)return;disposed=true;ribs.dispose();geometry.dispose();material.dispose();lineGeometry.dispose();lineMaterial.dispose();}};
}

