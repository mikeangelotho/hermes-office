import * as THREE from 'three';
import type { OfficeAgent } from '../domain/types.ts';
import { agentColor, routeFor, seatFor, type Point, type Seat } from './layout.ts';
import { Assets } from './room.ts';
import { PALETTE as P } from './palette.ts';

// Standing hip 1.21m; sitting hip .75m; shins and shoes place soles at floor .06m.
const RIG = { hip: 1.21, thigh: .46, shin: .60, shoulder: 1.70, upperArm: .30 } as const;

export class Character {
  root = new THREE.Group(); body = new THREE.Group();
  head = new THREE.Group(); leftArm = new THREE.Group(); rightArm = new THREE.Group();
  thighs: THREE.Group[] = []; calves: THREE.Group[] = []; elbows: THREE.Group[] = []; hands: THREE.Mesh[] = [];
  pick: THREE.Mesh; ring: THREE.Mesh; shadow: THREE.Mesh;
  seat: Seat; path: Point[] = []; phase: number; agent: OfficeAgent;
  private ringMaterial: THREE.MeshBasicMaterial;
  private shadowMaterial: THREE.MeshBasicMaterial;
  private chest: THREE.Mesh;
  private gazeYaw: number | null = null;
  private gazePitch: number | null = null;
  private gazePosition = new THREE.Vector3();
  private gazeCamera = new THREE.Vector3();
  constructor(a: Assets, agent: OfficeAgent, index: number, shadowTexture: THREE.Texture) {
    this.agent = agent; this.seat = seatFor(index, agent.state); this.phase = index * 1.73;
    this.root.position.set(this.seat.x, 0, this.seat.z); this.root.rotation.y = this.seat.rotation;
    this.root.add(this.body); const shirt = agentColor(agent.id);
    const skin = P.azure;
    const box = (color: string, size: number[], at: number[], parent: THREE.Object3D = this.body, kind = 'box') => a.mesh(color, size, at, kind, parent, 'agent');
    this.chest = box(shirt, [.54, .5, .31], [0, 1.45, 0], this.body, 'torso');
    box(P.metal, [.40, .19, .28], [0, RIG.hip, 0], this.body, 'torso');
    box(P.azure, [.027, .17, .02], [-.11, 1.48, .15]);
    box(P.frame, [.12, .12, .13], [0, 1.75, 0], this.body, 'limb');
    this.head.position.y = 1.89; this.body.add(this.head);
    const surface = box(skin, [.245, .29, .265], [0, 0, 0], this.head, 'head'); surface.name = 'head-surface';
    box(P.ice, [.145, .014, .012], [0, .012, .13], this.head);
    [this.leftArm, this.rightArm].forEach((arm, i) => {
      arm.position.set(i ? .32 : -.32, RIG.shoulder, 0); this.body.add(arm);
      box(shirt, [.15, RIG.upperArm, .17], [0, -RIG.upperArm / 2, 0], arm, 'limb');
      const elbow = new THREE.Group(); elbow.position.y = -RIG.upperArm; arm.add(elbow); this.elbows.push(elbow);
      box(P.frame, [.12, .29, .145], [0, -.145, 0], elbow, 'limb');
      const hand = box(P.azure, [.115, .11, .145], [0, -.355, .015], elbow, 'hand'); hand.name = 'hand'; this.hands.push(hand);
    });
    for (const x of [-.145, .145]) {
      const thigh = new THREE.Group(); thigh.position.set(x, RIG.hip, 0); this.body.add(thigh);
      box(shirt, [.18, RIG.thigh, .20], [0, -RIG.thigh / 2, 0], thigh, 'limb');
      const calf = new THREE.Group(); calf.position.y = -RIG.thigh; thigh.add(calf);
      box(P.frame, [.145, RIG.shin, .17], [0, -RIG.shin / 2, 0], calf, 'limb');
      const shoe = box(P.metal, [.18, .1, .30], [0, -.64, .08], calf); shoe.name = 'shoe';
      this.thighs.push(thigh); this.calves.push(calf);
    }
    this.pick = new THREE.Mesh(new THREE.BoxGeometry(.85, 2.25, .95), new THREE.MeshBasicMaterial({ visible: false }));
    this.pick.position.y = 1.05; this.pick.userData.agentId = agent.id; this.root.add(this.pick);
    this.ringMaterial = new THREE.MeshBasicMaterial({ color: P.azure, side: THREE.DoubleSide, transparent: true, opacity: .95, depthWrite: false });
    this.ring = new THREE.Mesh(new THREE.RingGeometry(.52, .59, 24), this.ringMaterial); this.ring.rotation.x = -Math.PI / 2; this.ring.position.y = .125; this.ring.visible = false; this.root.add(this.ring);
    this.shadowMaterial = new THREE.MeshBasicMaterial({ map: shadowTexture, transparent: true, opacity: .3, depthWrite: false });
    this.shadow = new THREE.Mesh(new THREE.PlaneGeometry(1.25, 1.25), this.shadowMaterial); this.shadow.rotation.x = -Math.PI / 2; this.shadow.position.y = .12; this.root.add(this.shadow);
    this.root.traverse(o => { if (o instanceof THREE.Mesh) o.castShadow = false; });
    this.tick(0, 0, true);
  }
  update(agent: OfficeAgent, index: number, reduced: boolean) {
    const next = seatFor(index, agent.state); this.agent = agent;
    if (next.kind !== this.seat.kind) {
      // Preserve the route from the actual position. Rapid toggles can reuse a
      // destination already on that route instead of cutting through furniture.
      const alreadyOnRoute = this.path.findIndex(p => p.x === next.x && p.z === next.z);
      const route = routeFor(this.seat, next).slice(1);
      this.path = reduced ? [] : alreadyOnRoute >= 0 ? this.path.slice(0, alreadyOnRoute + 1) : [...this.path, ...route];
      this.seat = next;
      if (reduced) this.root.position.set(next.x, 0, next.z);
    }
  }
  /** Aim relative to this head's screen position, not the center of the window. */
  lookAtCursor(pointer: THREE.Vector2 | null, camera: THREE.Camera) {
    this.gazeYaw = this.gazePitch = null;
    if (!pointer || this.seat.kind !== 'couch' || this.path.length || !Number.isFinite(pointer.x) || !Number.isFinite(pointer.y)) return false;
    camera.updateWorldMatrix(true, false);
    this.head.getWorldPosition(this.gazePosition).project(camera);
    camera.getWorldPosition(this.gazeCamera); this.root.worldToLocal(this.gazeCamera);
    if (!Number.isFinite(this.gazePosition.x) || !Number.isFinite(this.gazePosition.y)) return false;
    // A small viewer-facing bias makes screen-space tracking read naturally in isometric views.
    const facing = Math.atan2(this.gazeCamera.x, this.gazeCamera.z);
    this.gazeYaw = THREE.MathUtils.clamp(facing * .45 + (pointer.x - this.gazePosition.x) * .45, -.75, .75);
    this.gazePitch = THREE.MathUtils.clamp(.025 - (pointer.y - this.gazePosition.y) * .32, -.32, .32);
    return true;
  }
  tick(time: number, dt: number, reduced: boolean) {
    let walking = this.path.length > 0;
    if (walking) {
      const next = this.path[0]; const dx = next.x - this.root.position.x; const dz = next.z - this.root.position.z; const distance = Math.hypot(dx, dz); const step = dt * 3.1;
      if (distance <= step + .025) { this.root.position.x = next.x; this.root.position.z = next.z; this.path.shift(); walking = this.path.length > 0; }
      else { this.root.position.x += dx / distance * step; this.root.position.z += dz / distance * step; this.root.rotation.y = Math.atan2(dx, dz); }
    }
    if (!walking) this.root.rotation.y = this.seat.rotation;
    const t = reduced ? 0 : time + this.phase; const working = this.agent.state === 'working';
    this.body.position.y = walking ? Math.abs(Math.sin(t * 9)) * .035 : (this.seat.kind === 'couch' ? -.46 : -.47);
    const restPitch = working ? -.035 : this.seat.kind === 'couch' ? .025 : 0;
    if (walking || working || reduced) { this.head.rotation.y = 0; this.head.rotation.x = restPitch; }
    else {
      const restYaw = this.seat.kind === 'couch' ? 0 : Math.sin(t * .5) * .1;
      const seconds = Number.isFinite(dt) ? THREE.MathUtils.clamp(dt, 0, .1) : 0;
      this.head.rotation.y = THREE.MathUtils.damp(this.head.rotation.y, this.gazeYaw ?? restYaw, 9, seconds);
      this.head.rotation.x = THREE.MathUtils.damp(this.head.rotation.x, this.gazePitch ?? restPitch, 9, seconds);
    }
    this.thighs.forEach((leg, i) => { leg.rotation.x = walking ? Math.sin(t * 9 + i * Math.PI) * .55 : -Math.PI / 2; this.calves[i].rotation.x = walking ? Math.max(0, Math.sin(t * 9 + i * Math.PI)) * .4 : Math.PI / 2; });
    [this.leftArm, this.rightArm].forEach((arm, i) => {
      arm.rotation.x = walking ? Math.sin(t * 9 + (1 - i) * Math.PI) * .4 : working ? -1.35 : -.15;
      this.elbows[i].rotation.x = walking ? -.18 : working ? -.25 + (reduced ? 0 : Math.sin(t * (9 + i * 2)) * .035) : -.9;
    });
    this.shadowMaterial.opacity = this.agent.state === 'offline' ? .14 : .28;
  }
  select(selected: boolean) { this.ring.visible = selected; }
  dispose() { this.pick.geometry.dispose(); (this.pick.material as THREE.Material).dispose(); this.ring.geometry.dispose(); this.ringMaterial.dispose(); this.shadow.geometry.dispose(); this.shadowMaterial.dispose(); }
}
