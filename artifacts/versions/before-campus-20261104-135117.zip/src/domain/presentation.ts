import type { Team } from './types.ts';
export function presentationFor(search: string): { embedded: boolean; source: 'live' | 'demo'; team: Team } {
  const params = new URLSearchParams(search);
  const embedded = params.get('embed') === '1' || ['embedded', 'hero'].includes(params.get('view') ?? '');
  const rawTeam = params.get('team');
  const team: Team = ['general', 'studio', 'development', 'game', 'science'].includes(rawTeam ?? '') ? rawTeam as Team : 'studio';
  return { embedded, source: embedded || params.get('source') === 'demo' ? 'demo' : 'live', team };
}
